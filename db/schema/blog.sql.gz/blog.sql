-- phpMyAdmin SQL Dump
-- version 3.3.2deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 22, 2011 at 07:46 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.2-1ubuntu4.11

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `catergories`
--

CREATE TABLE IF NOT EXISTS `catergories` (
  `catergories` text NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catergories`
--


-- --------------------------------------------------------

--
-- Table structure for table `ci_login`
--

CREATE TABLE IF NOT EXISTS `ci_login` (
  `username` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ci_login`
--

INSERT INTO `ci_login` (`username`, `password`) VALUES
('12', 'c20ad4d76fe97759aa27a0c99bff6710');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `approved` int(11) NOT NULL,
  `name` text NOT NULL,
  `date` varchar(52) NOT NULL,
  `ip` varchar(25) NOT NULL,
  `comment` text NOT NULL,
  `entry_id` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `approved`, `name`, `date`, `ip`, `comment`, `entry_id`) VALUES
(10, 1, 'Hello', '08-16-2010', '127.0.0.1', 'Test', 1);

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE IF NOT EXISTS `post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(25) NOT NULL,
  `date` varchar(10) NOT NULL,
  `post` longtext NOT NULL,
  `posthash` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `title`, `date`, `post`, `posthash`) VALUES
(1, 'Sample Test', '07/18/2010', 'Sample Test', '0'),
(2, 'Test', '07/18/2010', 'TESt', '0'),
(3, 'Test', '07/18/2010', 'TESt', '0'),
(4, 'Test', '07/18/2010', 'TESt', '0'),
(5, 'Sample Test', '07/18/2010', 'TESTETESTS', '0'),
(6, 'Sample Test', '07/18/2010', 'TESTETESTS', '0'),
(7, 'TEST TEST', '07/18/2010', 'TEST TEST\n\nTEST\nTES\nTESt', '0'),
(8, 'This is pretty awesome', '08/11/2010', 'Neato magneto', '59b4f74df84eafea1c10f8bfa13f4f71'),
(9, 'Generated 5 paragraphs, 6', '08/16/2010', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec at libero ac ipsum dapibus dictum. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Donec elementum faucibus ipsum, a pharetra risus laoreet at. Nam at purus nunc. Morbi dictum bibendum diam, nec molestie neque elementum non. Vestibulum nisi neque, fringilla et placerat quis, iaculis in nisi. Vestibulum tempus consequat enim vel iaculis. Sed vel mi vitae odio adipiscing tempor et ut felis. Ut nec metus metus. Praesent a venenatis mauris. Aenean hendrerit lacus quis diam eleifend tempor. Nulla et nibh a leo condimentum hendrerit. Suspendisse imperdiet dolor dolor. Fusce at adipiscing tortor. In vulputate pellentesque quam, vitae aliquet ligula sollicitudin non. Nulla dictum enim in nunc mattis eu vehicula lacus aliquam. Nulla facilisi.\n\nAliquam erat volutpat. Morbi nisl metus, euismod non consectetur a, sagittis sagittis lacus. Morbi placerat, diam a convallis dignissim, tellus massa ullamcorper nisi, a congue eros lectus quis nunc. Sed eget justo sed nunc egestas vestibulum. Etiam vitae turpis eu libero pretium dictum sit amet et dui. Vivamus sem neque, cursus mattis fringilla non, eleifend semper dui. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aliquam aliquet mattis interdum. Aliquam at turpis vitae metus cursus iaculis in vitae ligula. Etiam eget nunc a sem faucibus vestibulum. Nam faucibus, diam ut viverra rutrum, orci massa volutpat lorem, vitae varius nibh elit et dolor. Donec sed nulla eros, sit amet porta erat. Sed a leo ac sapien vehicula pulvinar. Vivamus hendrerit blandit ornare. Sed ornare quam non sapien interdum mollis. Donec eget metus libero. Nullam porttitor eros sit amet mi luctus accumsan vitae a turpis. Aliquam suscipit lacus non turpis mollis porttitor. Cras dictum diam vitae turpis auctor facilisis.\n\nAliquam enim lacus, posuere vitae tincidunt ut, pretium vitae erat. Sed ultrices, velit consequat ultricies mattis, mi ligula pretium turpis, laoreet rutrum mi leo eget nisi. Curabitur mi arcu, eleifend a bibendum eget, blandit a ipsum. Nulla luctus porttitor fringilla. Aenean accumsan pellentesque dolor, vel varius metus aliquam non. Vivamus eget augue turpis. Mauris urna massa, adipiscing at luctus eu, rhoncus vitae nunc. Duis sit amet mauris sapien. Cras nibh enim, ornare in dictum et, pellentesque sodales arcu. Fusce eu mi vel dolor semper imperdiet quis non turpis. Maecenas nulla nisi, accumsan non tristique vel, luctus at ipsum.\n\nMaecenas porta porttitor neque vel vehicula. Duis nisi sapien, convallis quis euismod in, suscipit sit amet mi. Sed vel aliquam dolor. Duis sagittis nisl sit amet libero rutrum vel accumsan neque vehicula. Praesent mollis pellentesque convallis. Proin diam est, dapibus at mattis quis, facilisis ut nulla. Suspendisse ultrices nibh vitae ipsum mattis ut laoreet quam condimentum. Quisque id turpis leo. Duis eleifend ultrices pellentesque. Quisque sit amet nibh velit. Integer mi ipsum, porta in congue eget, condimentum at sem. Mauris nisl nulla, accumsan et euismod sagittis, blandit vel est. Praesent blandit ligula quam. Donec aliquet, lacus sed hendrerit pharetra, urna purus dictum ipsum, sagittis tempus purus dolor nec velit. Sed at augue nibh. Phasellus id tellus id libero molestie ornare.\n\nQuisque porta malesuada congue. Ut quis mi in libero laoreet interdum. Proin vestibulum sem eget nulla volutpat gravida. Donec pretium volutpat urna et tristique. Aenean sollicitudin purus eget mi fermentum quis pharetra magna dignissim. Donec posuere sodales diam vitae ornare. Nunc fermentum, nulla id malesuada viverra, nisl velit tincidunt orci, ac luctus urna metus ut ante. Nam viverra luctus neque, eu varius diam malesuada at. Phasellus eget condimentum magna. Phasellus venenatis dolor non nunc tristique suscipit. Vestibulum sagittis dolor vel ante elementum non iaculis nunc commodo. Cras eget nunc erat. Maecenas vulputate, eros tempus vestibulum pulvinar, ligula erat rutrum justo, in tincidunt elit urna eget neque. Phasellus mi justo, malesuada in placerat ut, imperdiet pretium tellus. Vivamus egestas, nulla at gravida lacinia, urna felis venenatis tellus, bibendum pharetra est eros tincidunt ligula. Etiam leo erat, dignissim eget tincidunt ut, dignissim sed risus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas lacinia augue nec sapien dapibus accumsan. In augue erat, posuere in interdum ac, eleifend quis augue. ', '2cadb8078d0635b3087c7e93a686b7d1'),
(10, 'Not Logged In', '08/26/2010', 'Will this work regardless of status', '7d644ea2d334fb5090ed8da4b333d6ea'),
(11, 'Test', '08/29/2010', 'This is another test message', '0cbc6611f5540bd0809a388dc95a615b'),
(12, 'Hello Helo', '08/29/2010', 'Hello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello HeloHello Helo', '4e471dd93669578dc189138c84c7fa98'),
(13, 'Always a Fricken lady', '12/23/2010', 'Sumo Awesomeness\n\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Sed placerat est eu lacus feugiat vitae ornare mi pharetra. Ut est odio, rutrum at placerat lobortis, gravida at neque. Aenean ac nulla sem. Proin blandit tellus lobortis mauris consequat volutpat. Nam augue erat, congue eget porttitor eget, suscipit a lacus. Sed interdum ullamcorper purus, in auctor dolor convallis eu. Aenean ac consectetur lectus. Curabitur et ante dictum nibh volutpat mattis nec ut quam. Aliquam nunc purus, fermentum eget tincidunt in, eleifend in quam. Aliquam risus tellus, gravida ut lobortis in, posuere quis velit. Praesent rutrum est id sem pellentesque tempus at eget tellus. Etiam et augue odio. Ut tincidunt sodales dolor, sed mollis purus volutpat vestibulum. Nulla commodo pulvinar massa sed mollis. Vivamus nulla ipsum, sagittis vitae laoreet sed, sagittis eget lacus. Fusce aliquam lacus et mauris placerat ac fringilla mauris dignissim. Suspendisse pellentesque lorem lorem. In hac habitasse platea dictumst.\n\nSuspendisse potenti. Sed at quam sem. Maecenas eu enim id urna porttitor placerat. In vestibulum pellentesque vestibulum. Donec sit amet erat sit amet mi vestibulum cursus et non lorem. Nunc erat diam, molestie vitae cursus a, condimentum eu nulla. Aenean tempor fringilla consequat. Vivamus congue massa at lorem varius pretium sodales orci lacinia. Quisque mollis erat rhoncus libero eleifend at viverra ante tincidunt. Vestibulum iaculis dictum metus ut dignissim. Integer vulputate, eros nec hendrerit dapibus, justo dui auctor urna, eu malesuada est arcu vel ante. Morbi porttitor turpis blandit leo congue sit amet vehicula nunc facilisis. Etiam vel orci nulla, id ornare urna. Proin enim ipsum, cursus id tristique quis, placerat ut dui.\n\nNunc et commodo turpis. Morbi ultrices tempus enim. Praesent viverra venenatis eros eu posuere. Phasellus libero ligula, commodo sit amet sodales nec, ullamcorper ornare quam. Integer non aliquam lacus. Pellentesque adipiscing scelerisque nisi, id luctus neque ullamcorper eu. Etiam vitae velit neque, et adipiscing ipsum. Nulla vitae ipsum sit amet enim hendrerit porttitor. Nullam id felis nisi. Etiam euismod sem sit amet lectus tincidunt tincidunt. Fusce porttitor ultrices risus imperdiet porttitor. In ultrices tincidunt nibh, ac ornare nibh semper et. Pellentesque pharetra elit et metus adipiscing dictum a eu odio. Praesent tempus hendrerit lobortis. Praesent diam sapien, bibendum in consequat id, tristique vel lorem.\n\nAenean porta, mauris at sagittis accumsan, enim massa placerat dui, ac vulputate purus tellus vel nunc. Suspendisse tincidunt, tellus eu facilisis ullamcorper, neque urna molestie ipsum, ac ultricies risus diam vel leo. Suspendisse potenti. Proin rutrum eros quis elit convallis convallis. Suspendisse ullamcorper lacinia lectus quis dignissim. Nunc ac risus mauris. Donec consectetur bibendum lacus, facilisis condimentum lectus ultricies a. Cras imperdiet aliquam nunc eu aliquam. Donec lacinia, enim vitae pharetra fringilla, sem magna laoreet nisi, et tempor ligula sem eget tellus. Maecenas vehicula nulla quis nibh consectetur iaculis. Etiam elit velit, varius in suscipit et, scelerisque sit amet magna. Sed a mauris quis felis lobortis rutrum. Nam sed ligula lorem, nec gravida urna. Donec consectetur est sit amet massa sagittis hendrerit. Morbi semper tellus et felis pellentesque ultrices non eget neque. Ut mi mi, porttitor sit amet sagittis ac, elementum non augue. Praesent augue massa, aliquet et rutrum a, interdum quis libero. Mauris sodales hendrerit sodales. Sed sodales eros faucibus velit tincidunt mollis. Duis at dolor lacus.\n\nEtiam tempor ante ut nisi vestibulum malesuada. Nulla id nibh sed nibh consectetur ultricies. Quisque odio mauris, fringilla quis elementum eget, feugiat volutpat purus. Duis blandit tellus ac quam malesuada id lacinia magna facilisis. Proin lacus risus, mattis sit amet vulputate egestas, pretium sed nisl. Mauris pretium nisl id leo fermentum id volutpat felis ullamcorper. Sed justo eros, semper at pulvinar mollis, varius ut lacus. Sed lorem augue, malesuada id porta vel, tempus quis nibh. Duis ullamcorper adipiscing nunc quis interdum. Praesent adipiscing sapien non odio aliquam gravida. Sed laoreet, purus ut luctus dignissim, eros enim cursus tellus, a consequat sapien tellus a arcu. Integer lobortis erat arcu, vel malesuada dui. Nullam ut purus nec purus pellentesque vestibulum. ', 'b6d403ecb8730d687d616c544d817422'),
(14, 'Hello', '12/24/2010', 'This is a test', '8b1a9953c4611296a827abf8c47804d7'),
(29, 'Today is a good day', '07/12/2011', 'Hey there and awesome.\n\nThis is a good day.\n', '4e1c38cd5cf79'),
(21, 'test', '07/08/2011', 'test', 'test4e17a6a04fcf1'),
(22, 'jhgjhghgfhgfhgf', '07/09/2011', 'vhgghgfhgfhgfhgfhgf', 'jhgjhghgfhgfhgf4e1845fd85915'),
(23, 'fdfdafasfdf', '07/09/2011', 'dfdsafdfsafa', 'fdfdafasfdf4e18464711888'),
(24, 'fdfdafasfdf', '07/09/2011', 'dfdsafdfsafa', 'fdfdafasfdf4e18467452db2'),
(25, 'fdfdafasfdf', '07/09/2011', 'dfdsafdfsafa', 'fdfdafasfdf4e184697db131'),
(26, 'fdfdafasfdf', '07/09/2011', 'dfdsafdfsafa', 'fdfdafasfdf4e1846a041a2f'),
(27, 'dfaddfdafdaf', '07/09/2011', 'dadfdfadfadfs', 'dfaddfdafdaf4e1846ac22bd6'),
(28, 'dfasssssssssssssssfadaf', '07/09/2011', 'adfadfdsfdfdfafafdsf', 'dfasssssssssssssssfadaf4e18996b6a0aa');
